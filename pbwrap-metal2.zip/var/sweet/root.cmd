# sweetroot command file: gives PosterBoard the tracing dylib, once.
#
# Delivered by the dropbox (/var/sweet/root.cmd) and applied at boot by /usr/local/bin/sweetroot. The first
# operation must be "apply": without it sweetroot only prints what it would do. Log: /var/tmp/sweetroot.log
apply

# the untouched binary, kept once (cp -n never overwrites what an earlier boot made)
cp -n /Applications/PosterBoard.app/PosterBoard /Applications/PosterBoard.app/PosterBoard.orig

# the copy that install-wrap adds LC_LOAD_DYLIB to; it also fixes the first page's code signature hash
cp -n /Applications/PosterBoard.app/PosterBoard.orig /Applications/PosterBoard.app/PosterBoard.inj
# "patch: 0" done, "patch: 1" already there, "patch: -2" no room for the load command (the binary's header is full),
# other negatives: not a Mach-O, not arm64, or a signature this code cannot rewrite
run /usr/local/bin/install-wrap --patch /Applications/PosterBoard.app/PosterBoard.inj /usr/lib/sweetposter.dylib
# "verify: 0" first page of every arm64 slice matches its signature again; negative: the hash still differs, so the
# kernel will not take the binary and the interposition would look like a failure of its own
run /usr/local/bin/install-wrap --verify /Applications/PosterBoard.app/PosterBoard.inj

# the wrapper takes the place of the real binary and starts .inj (after two quick crashes: .orig)
cp /usr/local/libexec/pbwrap /Applications/PosterBoard.app/PosterBoard
chmod 755 /Applications/PosterBoard.app/PosterBoard
ls /Applications/PosterBoard.app

# no relaunch here: there is no killall on the phone (boot 2026-11-23). PosterBoard dies 30-70 s after each launch
# anyway, and launchd starts it again through the wrapper.

# To go back (a later root.cmd, or the same file with these two lines uncommented):
# cp /Applications/PosterBoard.app/PosterBoard.orig /Applications/PosterBoard.app/PosterBoard
