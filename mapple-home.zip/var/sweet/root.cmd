# nothing to do (the Mapple home-screen boot; without "apply" sweetroot only prints)
